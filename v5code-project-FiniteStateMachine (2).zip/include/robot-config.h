using namespace vex;

extern brain Brain;

// VEXcode devices
extern motor LeftMotor;
extern motor RightMotor;
extern line RightLineTracker;
extern line LeftLineTracker;
extern sonar RangeFinder;
extern motor IntakeMotor;
extern controller Controller1;
extern motor ArmMotor1;
extern motor ArmMotor2;

/**
 * Used to initialize code/tasks/devices added using tools in VEXcode Pro.
 * 
 * This should be called at the start of your int main function.
 */
void  vexcodeInit( void );