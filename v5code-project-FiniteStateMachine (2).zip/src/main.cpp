/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       C:\Users\rando                                            */
/*    Created:      Tue Nov 02 2021                                           */
/*    Description:  V5 project                                                */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// LeftMotor            motor         1               
// RightMotor           motor         2               
// RightLineTracker     line          B               
// LeftLineTracker      line          A               
// RangeFinder          sonar         E, F            
// IntakeMotor          motor         13              
// Controller1          controller                    
// ArmMotor1            motor         11              
// ArmMotor2            motor         12              
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "vex.h"

const float Kp = 1;
float effort = 0;
float error = 0;
float motorSpeed = 80;

const double wheelDiameter = 3.94;
const double wheelCircumference = 3.1415 * wheelDiameter;
const double gearRatio = 5;
const double wheelTrack = 11.22;
const double degreesPerInch = 360/wheelCircumference;
const double rotDegreesLin = degreesPerInch*gearRatio;
const double motorVeloPercent = 100;

double leftSensor = 0.0;
double rightSensor = 0.0;
double leftMotorPower = 0.0;
double rightMotorPower = 0.0;

float distanceTraveled = 0.0;
float leftTracker = 0.0;
float rightTracker = 0.0;

const float KpDistance = 0.5;
const float KpAngle = 0.5;
const float ScreenXHalf = 316/2;


void driveForward(float distance, float motorPower){ //Negative distance drives backwards

  //Sets the motor velocities to a specified percentage of their maximum speed
  LeftMotor.setVelocity(motorPower, percent);
  RightMotor.setVelocity(motorPower, percent);

  //LeftMotor.startRotateFor(rotdegrees, rotationUnits::rev, 100, velocityUnits::rpm);
  //RightMotor.rotateFor(degrees, rotationUnits::rev, 100, velocityUnits::rpm);

  LeftMotor.spinFor(forward, rotDegreesLin * distance, degrees, false);
  RightMotor.spinFor(forward, rotDegreesLin * distance, degrees,true);

  //Resets the motors to the previously declared global value
  LeftMotor.setVelocity(motorVeloPercent, percent);
  RightMotor.setVelocity(motorVeloPercent, percent);

}

void turnLeft(float Angle, float motorPower) {

  double rotDegreesTurn = Angle * gearRatio * wheelTrack / wheelDiameter;

  //Sets the motor velocities to a specified percentage of their maximum speed
  LeftMotor.setVelocity(motorPower, percent);
  RightMotor.setVelocity(motorPower, percent);

  LeftMotor.spinFor(forward, rotDegreesTurn, degrees, false);
  RightMotor.spinFor(reverse, rotDegreesTurn, degrees, true);

  //Resets the motors to the previously declared global value
  LeftMotor.setVelocity(motorVeloPercent, percent);
  RightMotor.setVelocity(motorVeloPercent, percent);

}

void turnRight(float angle, float motorPower) {

  double rotDegreesTurn = angle * gearRatio * wheelTrack / wheelDiameter;

  //Sets the motor velocities to a specified percentage of their maximum speed
  LeftMotor.setVelocity(motorPower, percent);
  RightMotor.setVelocity(motorPower, percent);

  LeftMotor.spinFor(forward, rotDegreesTurn, degrees, false);
  RightMotor.spinFor(reverse, rotDegreesTurn, degrees, true);

  //Resets the motors to the previously declared global value
  LeftMotor.setVelocity(motorVeloPercent, percent);
  RightMotor.setVelocity(motorVeloPercent, percent);

}

void followWall(double travelDistance, double motorSpeed){
  
  bool flag = true;
  double distanceTravelled = 0;
  double adjust = LeftMotor.position(degrees);

  while (flag) {
    error = RangeFinder.distance(inches) - 4.287;  // 5" is the set point
    effort = Kp * error;
    distanceTravelled = (LeftMotor.position(degrees) - adjust)/ rotDegreesLin;

    LeftMotor.setVelocity(motorSpeed + effort, percent);
    RightMotor.setVelocity(motorSpeed - effort, percent);
    
    LeftMotor.spin(forward);
    RightMotor.spin(forward);

  }
}

void spinSearch(){
  while (RightLineTracker.reflectivity() < 50){
  rightTracker = RightLineTracker.reflectivity();
  turnRight(5, 30);
 }
}

void Stop(){
  LeftMotor.stop();
  RightMotor.stop();
}

void searchWhiteLine(){
  bool flag = true;
  while(flag){
   driveForward(0.75, 100);
    if((RightLineTracker.reflectivity() > 50) || (LeftLineTracker.reflectivity() > 50)){
      flag = false;
      Stop();
    }
  }
}

void searchBlackLine(){
  bool flag = true;
  while(flag){
   driveForward(1, 100);
    if((RightLineTracker.reflectivity() < 50) || (LeftLineTracker.reflectivity() < 50)){
      flag = false;
      Stop();
    }
  }
}

void followBlackLine(float travelDistance, float motorPower){
 //float distanceTraveled = 0.0;
 bool flag = true;
 double distanceTravelled = 0;
 double adjust = LeftMotor.position(degrees);
 LeftMotor.setVelocity(motorPower, percent);
 RightMotor.setVelocity(motorPower, percent);
}

void followWhiteLine(float travelDistance, float motorPower){
 //float distanceTraveled = 0.0;
 bool flag = true;
 double distanceTravelled = 0;
 double adjust = LeftMotor.position(degrees);
 LeftMotor.setVelocity(motorPower, percent);
 RightMotor.setVelocity(motorPower, percent);

 while (flag) {
  distanceTravelled = (LeftMotor.position(degrees) - adjust)/ rotDegreesLin;
  LeftMotor.spin(forward);
  RightMotor.spin(forward);
  leftTracker = LeftLineTracker.reflectivity();
  rightTracker = RightLineTracker.reflectivity();
 if ((rightTracker < 50) && (leftTracker < 50)){
    LeftMotor.setVelocity(motorPower, percent);
    RightMotor.setVelocity(motorPower, percent);
  } else if(leftTracker > 50){
  
    LeftMotor.setVelocity(motorPower - 10, percent);
    RightMotor.setVelocity(motorPower + 20, percent);
  
  } else if (rightTracker > 50){
  
    LeftMotor.setVelocity(motorPower + 20, percent);
    RightMotor.setVelocity(motorPower - 10, percent);
    
  }
  
  if(travelDistance <= distanceTravelled)
   flag = false;
 }
  LeftMotor.stop();
  RightMotor.stop();
}

//Defines the states of the Finite State Machine
typedef enum STATE{
  
  RAMP,
  PIZZA_ONE,
  PIZZA_TWO,
  PIZZA_THREE,
  PIZZA_FOUR,
  PIZZA_FIVE,
  PIZZA_SIX,
  CONSTRUCTION

}  State;

State ramp(){

  wait(0.5, seconds);
  followWall(10, 70);
  //turnArm(100, 20);
  followWall(100, 40);
  driveForward(10, 50);
  turnRight(90, 50);
  driveForward(10, 50);
  followWall(20, 50);
  wait(2, seconds);
  turnLeft(90, 50);
  followWall(44, 50);
  followWall(20, 100);
  searchWhiteLine();
  spinSearch();
  followWhiteLine(30, 50);

  return PIZZA_ONE;

}
  
//}
using namespace vex;

int main() {
  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();

  while(true){

 }
 
}
